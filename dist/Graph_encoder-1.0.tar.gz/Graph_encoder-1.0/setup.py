from distutils.core import setup
setup(name="Graph_encoder",
    version='1.0',
	packages=['examples', 'examples/modules'])
